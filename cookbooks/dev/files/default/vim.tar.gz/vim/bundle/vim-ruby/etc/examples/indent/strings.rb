command = %|#{file}|
settings.log.info("Returning: #{command}")
