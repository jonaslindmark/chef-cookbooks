vimconfig
=========

My plugins and vimrc

Notes
==================
Requires vim to be compiled with ruby and python support

Install notes
==================

- git clone to .vim folder in $HOME
- ln -s ~/.vim/vimrc ~/.vimrc
- git submodule init
- git submodule update
- cd ~/.vim/bundle/Command-T/ruby; ruby extconf.rb; make
